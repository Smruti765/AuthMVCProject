﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace AuthMVCProject.Controllers
{
    [Authorize]  // सभी actions के लिए Authentication अनिवार्य
    public class DashboardController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Profile()
        {
            return View();
        }

        public IActionResult Reports()
        {
            return View();
        }

        public IActionResult Settings()
        {
            return View();
        }

        [Authorize(Roles = "Admin")]  // केवल Admin के लिए
        public IActionResult AdminPanel()
        {
            return View();
        }
    }
}
